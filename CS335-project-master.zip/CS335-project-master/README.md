# CS335-project
club collaboration timetabler


storyboard :
https://trello.com/b/rh1fqQHl/untitled-board
